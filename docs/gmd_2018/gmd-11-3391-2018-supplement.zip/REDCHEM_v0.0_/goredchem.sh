./exe_rc >log_redchem.txt 
